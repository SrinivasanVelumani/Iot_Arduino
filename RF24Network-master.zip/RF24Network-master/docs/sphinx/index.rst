
:hero: Newly Optimized RF24Network Layer

Introduction
=============

.. doxygenpage:: index
    :content-only:

Site Index
-----------

:ref:`Site index<genindex>`

.. toctree::
    :maxdepth: 2
    :caption: API Reference
    :hidden:

    classRF24Network
    net_payload_structs
    RF24Network__config_8h
    deprecated


.. toctree::
    :maxdepth: 1
    :hidden:

    pages


.. toctree::
    :maxdepth: 1
    :caption: Modules
    :hidden:

    group__DEFINED_TYPES

.. toctree::
    :maxdepth: 2
    :hidden:

    examples
