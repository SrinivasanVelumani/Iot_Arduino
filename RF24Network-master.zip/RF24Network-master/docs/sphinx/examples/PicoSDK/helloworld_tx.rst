helloworld_tx
==========================

.. seealso::
    `defaultPins.h <default_pins.html>`_

.. literalinclude:: ../../../../examples_pico/helloworld_tx.cpp
    :caption: examples_pico/helloworld_tx.cpp
    :linenos:
