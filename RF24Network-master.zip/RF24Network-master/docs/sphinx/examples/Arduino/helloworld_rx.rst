helloworld_rx.ino
=================

.. literalinclude:: ../../../../examples/helloworld_rx/helloworld_rx.ino
    :linenos:
